import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import calendar
import os
from datetime import datetime
import logging
import webbrowser

# -------------------------
# Setup logging
# -------------------------
log_file = "logs/Pipeline_log.txt"
os.makedirs("logs", exist_ok=True)
logging.basicConfig(filename=log_file, level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
logging.info("Pipeline started")

# -------------------------
# Load data
# -------------------------
data_file = "raw_data/DataCo.zip"
if not os.path.exists(data_file):
    logging.error(f"Data file not found: {data_file}")
    raise FileNotFoundError(f"{data_file} not found")

try:
    df = pd.read_csv(data_file, compression="zip", encoding="latin1")
except UnicodeDecodeError:
    df = pd.read_csv(data_file, compression="zip", encoding="cp1252")

logging.info(f"Data loaded successfully: {len(df)} rows")

# -------------------------
# Handle dates
# -------------------------
date_cols = [c for c in df.columns if "order_date" in c.lower()]
if date_cols:
    date_col = date_cols[0]
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df["Year"] = df[date_col].dt.year
    df["Month_Num"] = df[date_col].dt.month
    df["Month_Name"] = df["Month_Num"].apply(lambda x: calendar.month_abbr[x] if pd.notnull(x) else "")
else:
    logging.error("No order_date column found")
    raise Exception("No order_date column found")

# Revenue & on-time
if all(col in df.columns for col in ["Order_Item_Product_Price","Order_Item_Quantity","Order_Item_Discount"]):
    df["Revenue"] = (df["Order_Item_Product_Price"]*df["Order_Item_Quantity"]) - df["Order_Item_Discount"]

if "Late_delivery_risk" in df.columns:
    df["on_time"] = df["Late_delivery_risk"].apply(lambda x: 1 if x==0 else 0)

# -------------------------
# Optional filter (here we use full dataset)
# -------------------------
filtered_data = df.copy()

# -------------------------
# KPIs
# -------------------------
total_orders = filtered_data["Order_Id"].nunique() if "Order_Id" in filtered_data.columns else 0
total_customers = filtered_data["Customer_Id"].nunique() if "Customer_Id" in filtered_data.columns else 0
total_revenue = filtered_data["Revenue"].sum() if "Revenue" in filtered_data.columns else 0
total_profit = filtered_data["Order_Profit_Per_Order"].sum() if "Order_Profit_Per_Order" in filtered_data.columns else 0

total_revenue_m = total_revenue / 1_000_000
total_profit_m = total_profit / 1_000_000
aov = total_revenue / total_orders if total_orders>0 else 0
total_items_sold = filtered_data["Order_Item_Quantity"].sum() if "Order_Item_Quantity" in filtered_data.columns else 0
total_deliveries = filtered_data[filtered_data["shipping_date_DateOrders"].notna()]["Order_Id"].nunique() if "shipping_date_DateOrders" in filtered_data.columns else 0
on_time_deliveries = filtered_data[filtered_data["Late_delivery_risk"]==0]["Order_Id"].nunique() if "Late_delivery_risk" in filtered_data.columns else 0
on_time_delivery_pct = (on_time_deliveries/total_deliveries*100) if total_deliveries>0 else 0
late_deliveries = filtered_data[filtered_data["Late_delivery_risk"]==1]["Order_Id"].nunique() if "Late_delivery_risk" in filtered_data.columns else 0
delivery_sla_breach_pct = (late_deliveries/total_deliveries*100) if total_deliveries>0 else 0

logging.info("KPIs calculated")

# -------------------------
# Generate Charts
# -------------------------
os.makedirs("output", exist_ok=True)
charts = []

# Helper function to save chart
def save_chart(fig, name):
    path = f"output/{name}.png"
    fig.savefig(path, bbox_inches='tight')
    plt.close(fig)
    charts.append((name, path))

# 1. Monthly Orders Trend
if "Month_Num" in filtered_data.columns and "Order_Id" in filtered_data.columns:
    monthly_orders = filtered_data.groupby("Month_Num")["Order_Id"].nunique().reset_index()
    monthly_orders["Month_Name"] = monthly_orders["Month_Num"].apply(lambda x: calendar.month_abbr[x])
    monthly_orders = monthly_orders.sort_values("Month_Num")
    fig, ax = plt.subplots(figsize=(12,6))
    sns.lineplot(data=monthly_orders, x="Month_Name", y="Order_Id", marker="o", color="teal", ax=ax)
    for i, row in monthly_orders.iterrows():
        ax.text(row["Month_Name"], row["Order_Id"]*1.02, f"{row['Order_Id']}", ha="center", va="bottom")
    ax.set_xlabel("Month")
    ax.set_ylabel("Orders")
    ax.grid(True, linestyle="--", alpha=0.6)
    save_chart(fig, "Monthly_Orders_Trend")

# 2. Top 10 Product Categories by Revenue
if "Category_Name" in filtered_data.columns and "Revenue" in filtered_data.columns:
    revenue_by_category = filtered_data.groupby("Category_Name")["Revenue"].sum().nlargest(10).sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(10,6))
    revenue_by_category.plot(kind="barh", color="teal", ax=ax)
    for i, val in enumerate(revenue_by_category):
        ax.text(val, i, f"{val:,.0f}", va="center", ha="left")
    ax.set_xlabel("Revenue")
    ax.set_ylabel("Category")
    ax.grid(axis="x", linestyle="--", alpha=0.6)
    save_chart(fig, "Top10_Product_Categories")

# 3. Orders by Customer Segment (Pie)
if "Customer_Segment" in filtered_data.columns and "Order_Id" in filtered_data.columns:
    orders_by_segment = filtered_data.groupby("Customer_Segment")["Order_Id"].nunique().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(7,7))
    ax.pie(orders_by_segment, labels=orders_by_segment.index,
           autopct=lambda p: f'{p:.1f}%\n({int(p*orders_by_segment.sum()/100):,})',
           startangle=90, counterclock=False)
    save_chart(fig, "Orders_by_Customer_Segment")

# 4. Top 10 Products by Revenue
if "Product_Name" in filtered_data.columns and "Revenue" in filtered_data.columns:
    revenue_by_product = filtered_data.groupby("Product_Name")["Revenue"].sum().nlargest(10).sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(10,6))
    revenue_by_product.plot(kind="barh", color="teal", ax=ax)
    for i, val in enumerate(revenue_by_product):
        ax.text(val, i, f"${val:,.0f}", va="center", ha="left")
    ax.set_xlabel("Revenue")
    ax.set_ylabel("Product Name")
    ax.grid(axis="x", linestyle="--", alpha=0.6)
    save_chart(fig, "Top10_Products")

# 5. Average On-Time Delivery % by Month
if "on_time" in filtered_data.columns:
    on_time_trend = filtered_data.groupby('Month_Num')['on_time'].mean()*100
    on_time_trend = on_time_trend.reset_index()
    on_time_trend['Month_Name'] = on_time_trend['Month_Num'].apply(lambda x: calendar.month_abbr[x])
    on_time_trend = on_time_trend.sort_values('Month_Num')
    fig, ax = plt.subplots(figsize=(12,6))
    ax.plot(on_time_trend['Month_Name'], on_time_trend['on_time'], marker='o', color='teal', linewidth=2)
    for i, val in enumerate(on_time_trend['on_time']):
        ax.text(i, val + 0.1, f"{val:.1f}%", ha='center', va='bottom')
    ax.set_xlabel("Month")
    ax.set_ylabel("On-Time Delivery %")
    ax.grid(True, linestyle="--", alpha=0.6)
    save_chart(fig, "OnTime_Delivery_by_Month")

# 6. Top 10 Products with Late Deliveries
if "Late_delivery_risk" in filtered_data.columns and "Product_Name" in filtered_data.columns:
    late_by_product = filtered_data[filtered_data['Late_delivery_risk']==1]['Product_Name'].value_counts().nlargest(10).sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(10,6))
    late_by_product.plot(kind="barh", color="salmon", ax=ax)
    for i, val in enumerate(late_by_product):
        ax.text(val, i, f"{val}", va='center', ha='left')
    ax.set_xlabel("Late Deliveries Count")
    ax.set_ylabel("Product Name")
    ax.grid(axis="x", linestyle="--", alpha=0.6)
    save_chart(fig, "Top10_Late_Deliveries")

# -------------------------
# 7. On-time vs Late Deliveries by Shipping Mode
# -------------------------
if "Shipping_Mode" in filtered_data.columns and "Late_delivery_risk" in filtered_data.columns:
    stitle = "On-Time vs Late Deliveries by Shipping Mode"
    delivery_by_shipmode = filtered_data.groupby(['Shipping_Mode','Late_delivery_risk']).size().unstack(fill_value=0)
    delivery_by_shipmode.columns = ['On-time','Late']
    fig, ax = plt.subplots(figsize=(10,6))
    delivery_by_shipmode.plot(kind='bar', color=['teal','salmon'], ax=ax)
    for p in ax.patches:
        ax.annotate(str(int(p.get_height())), (p.get_x()+p.get_width()/2, p.get_height()),
                    ha='center', va='bottom', fontsize=9)
    ax.set_ylabel("Number of Deliveries")
    ax.set_xlabel("Shipping Mode")
    ax.set_xticklabels(delivery_by_shipmode.index, rotation=0)
    ax.grid(axis='y', linestyle='--', alpha=0.6)
    save_chart(fig, "OnTime_vs_Late_by_Shipping_Mode")

# -------------------------
# 8. Late Deliveries by Shipping Mode (Pie)
# -------------------------
late_by_shipmode = filtered_data[filtered_data['Late_delivery_risk']==1]['Shipping_Mode'].value_counts()
if not late_by_shipmode.empty:
    stitle = "Late Deliveries by Shipping Mode"
    fig, ax = plt.subplots(figsize=(7,7))
    ax.pie(
        late_by_shipmode,
        labels=late_by_shipmode.index,
        autopct=lambda p: f'{p:.1f}%\n({int(p*late_by_shipmode.sum()/100):,})',
        startangle=90,
        counterclock=False,
        colors=['teal','salmon','gold','lightblue']
    )
    save_chart(fig, "Late_Deliveries_by_Shipping_Mode")

# -------------------------
# 9. Orders by Shipping Mode (Pie)
# -------------------------
if "Shipping_Mode" in filtered_data.columns and "Order_Id" in filtered_data.columns:
    stitle = "Orders by Shipping Mode"
    orders_by_shipmode = filtered_data.groupby('Shipping_Mode')['Order_Id'].nunique()
    fig, ax = plt.subplots(figsize=(7,7))
    ax.pie(
        orders_by_shipmode,
        labels=orders_by_shipmode.index,
        autopct=lambda p: f'{p:.1f}%\n({int(p*orders_by_shipmode.sum()/100):,})',
        startangle=90,
        counterclock=False,
        colors=['teal','salmon','gold','lightblue']
    )
    save_chart(fig, "Orders_by_Shipping_Mode")

# -------------------------
# 10. Total Customers by Shipping Mode
# -------------------------
if "Shipping_Mode" in filtered_data.columns and "Customer_Id" in filtered_data.columns:
    stitle = "Total Customers by Shipping Mode"
    customers_by_shipmode = filtered_data.groupby('Shipping_Mode')['Customer_Id'].nunique().sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(10,6))
    customers_by_shipmode.plot(kind='barh', color='teal', ax=ax)
    for i, val in enumerate(customers_by_shipmode):
        ax.text(val, i, f"{val}", va='center', ha='left', fontsize=9)
    ax.set_xlabel("Number of Distinct Customers")
    ax.set_ylabel("Shipping Mode")
    ax.grid(axis='x', linestyle='--', alpha=0.6)
    save_chart(fig, "Total_Customers_by_Shipping_Mode")

# -------------------------
# 11. Late Deliveries by Shipping Mode (Column)
# -------------------------
if "Shipping_Mode" in filtered_data.columns and "Late_delivery_risk" in filtered_data.columns:
    stitle = "Late Deliveries by Shipping Mode (Column)"
    late_deliveries = filtered_data[filtered_data['Late_delivery_risk']==1].groupby('Shipping_Mode')['Order_Id'].count()
    fig, ax = plt.subplots(figsize=(10,6))
    late_deliveries.sort_values(ascending=False).plot(kind='bar', color='salmon', ax=ax)
    for i, val in enumerate(late_deliveries.sort_values(ascending=False)):
        ax.text(i, val+0.5, f"{val}", ha='center', va='bottom', fontsize=9)
    ax.set_xlabel("Shipping Mode")
    ax.set_ylabel("Number of Late Deliveries")
    ax.grid(axis='y', linestyle='--', alpha=0.6)
    save_chart(fig, "Late_Deliveries_by_Shipping_Mode_Column")


logging.info("Charts generated")

# -------------------------
# Generate HTML report
# -------------------------
html_file = "output/Supply_Chain_Report.html"
with open(html_file, "w") as f:
    f.write(f"<html><head><title>Supply Chain Report</title></head><body>")
    f.write(f"<h1>Supply Chain Dashboard Report - {datetime.today().date()}</h1>")
    f.write(f"<h2>Key Metrics</h2><ul>")
    f.write(f"<li>Total Orders: {total_orders}</li>")
    f.write(f"<li>Total Customers: {total_customers}</li>")
    f.write(f"<li>Total Revenue: ${total_revenue_m:,.2f}M</li>")
    f.write(f"<li>Total Profit: ${total_profit_m:,.2f}M</li>")
    f.write(f"<li>AOV: ${aov:,.2f}</li>")
    f.write(f"<li>Total Items Sold: {total_items_sold}</li>")
    f.write(f"<li>On-Time Delivery %: {on_time_delivery_pct:.2f}%</li>")
    f.write(f"<li>Delivery SLA Breach %: {delivery_sla_breach_pct:.2f}%</li>")
    f.write("</ul>")

    for title, path in charts:
        f.write(f"<h2>{title}</h2>")
        f.write(f"<img src='{os.path.basename(path)}' style='width:700px;'>")

    f.write("</body></html>")

logging.info(f"Report saved to {html_file}")
print(f"Report saved to {html_file}")

# Open the HTML report automatically
webbrowser.open('file://' + os.path.realpath(html_file))
